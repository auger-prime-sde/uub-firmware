git diff amiga_buffer master sde_trigger_code.vh
