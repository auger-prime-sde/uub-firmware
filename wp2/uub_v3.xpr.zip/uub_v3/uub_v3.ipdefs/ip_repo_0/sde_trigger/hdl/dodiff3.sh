echo "=====sde_trigger_code.vh" >dodiff3.log
diff -w sde_trigger_code.vh /tmp/gitfiles/sde_trigger_code.vh >>dodiff3.log
echo "=====sde_trigger_regs.vh" >>dodiff3.log
diff -w sde_trigger_regs.vh /tmp/gitfiles/sde_trigger_regs.vh >>dodiff3.log
echo "=====sde_trigger_S00_AXI.v" >>dodiff3.log
diff -w sde_trigger_S00_AXI.v /tmp/gitfiles/sde_trigger_S00_AXI.v >>dodiff3.log
echo "=====sde_trigger.v" >>dodiff3.log
diff -w sde_trigger.v /tmp/gitfiles/sde_trigger.v >>dodiff3.log

